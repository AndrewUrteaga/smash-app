module.exports = {
  // disbable logging for production
  logging: false
};
