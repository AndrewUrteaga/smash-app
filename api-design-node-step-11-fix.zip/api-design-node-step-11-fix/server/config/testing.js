module.exports = {
  // disbable logging for testing
  logging: false,
  db: {
    url: 'mongodb://localhost/nodeblog-test'
  }
};
